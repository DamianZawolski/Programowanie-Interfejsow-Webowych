import { useState } from "react"

const ContactModal = () => {
    const [open, setOpen] = useState(false);

    return 
}